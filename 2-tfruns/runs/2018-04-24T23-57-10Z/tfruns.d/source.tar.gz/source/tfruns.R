library(tfruns)
library(here)


setwd(here("2-tfruns"))
tfruns::training_run("mnist_cnn.R")

job_status()
job_collect()
view_runs()
ls_runs()
ls_runs(eval_acc > 0.97)

setwd(here())
